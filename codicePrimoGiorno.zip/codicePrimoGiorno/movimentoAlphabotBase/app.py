from flask import Flask, render_template, request
#render_template funzione che permette di fare l'aggirnamento della pagina
#request variabile in cui quando si fa il submit del form si salvano i dati inseriti
from provaConSensori import AlphaBot

Ab = AlphaBot()

#pagnia 1
app = Flask(__name__)
@app.route("/", methods=["GET"]) #"/" rappresenta index e i metodi
def index():
    return render_template("index.html")

#os.getcwd() --> ti da in che cartella é il progetto
# app.template_folder -->
# 

#pagina 2
@app.route("/result", methods=["POST", "GET"]) #dopo lo / metto il nome della funzione che viene eseguita e viene eseguita solo se l'ho richiesta con un metodo post se no mi visualizza errore
#dovremmo accettare tutti i metodi e gestire le casistiche
def result():
    #quindi fare questo solo se il metodo é uguale a post e per avere il metodo con cui l'utente ha fatto l'accesso alla pagina con request.method 
    if(request.method == "POST"):
        movimentoRicevuto = request.form.get("bottone").value
        if movimentoRicevuto == "av":
            Ab.forward()
        elif movimentoRicevuto == "in":
            Ab.backward()
        elif movimentoRicevuto == "si":
            Ab.left()
        elif movimentoRicevuto == "de":
            Ab.right()
        elif movimentoRicevuto == "s":
            Ab.stop()
        elif movimentoRicevuto == "90r":
            Ab.r90()
        elif movimentoRicevuto == "90l":
            Ab.l90()
        else:
            print("Comando non riconosciuto.")
        return render_template("index.html")
    else: 
        return render_template("index.html")

if __name__ == "__main__":
    app.run(debug=True) #permette di testare riga per riga mettendo il puntino a sinistra e si blocca arrivata a quella riga, lo puoi mettere senza e in quel caso se c'é un errore l'app si blocca o si arresta in base al tipo di errore