from flask import Flask, render_template, request
#render_template funzione che permette di fare l'aggirnamento della pagina
#request variabile in cui quando si fa il submit del form si salvano i dati inseriti

#pagnia 1
app = Flask(__name__)
@app.route("/", methods=["GET"]) #"/" rappresenta index e i metodi
def index():
    return render_template("index.html")

#os.getcwd() --> ti da in che cartella é il progetto
# app.template_folder -->
# 

#pagina 2
@app.route("/result", methods=["POST", "GET"]) #dopo lo / metto il nome della funzione che viene eseguita e viene eseguita solo se l'ho richiesta con un metodo post se no mi visualizza errore
#dovremmo accettare tutti i metodi e gestire le casistiche
def result():
    #quindi fare questo solo se il metodo é uguale a post e per avere il metodo con cui l'utente ha fatto l'accesso alla pagina con request.method 
    if(request.method == "POST"):
        nomeRicevuto = request.form.get("nome")
        numeroRicevuto = request.form.get("numero")
        return render_template("result.html", nome=nomeRicevuto, numero=numeroRicevuto)
    else: 
        return render_template("index.html")

if __name__ == "__main__":
    app.run(debug=True) #permette di testare riga per riga mettendo il puntino a sinistra e si blocca arrivata a quella riga, lo puoi mettere senza e in quel caso se c'é un errore l'app si blocca o si arresta in base al tipo di errore