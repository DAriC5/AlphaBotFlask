from flask import Flask, render_template, request, jsonify
from provaConSensori import AlphaBot

Ab = AlphaBot()

app = Flask(__name__)

@app.route("/", methods=["GET"])
def index():
    return render_template("index.html")

@app.route("/result", methods=["POST", "GET"])
def result():
    if request.method == "POST":
        movimentoRicevuto = request.form.get("bottone")
        trim  = int(request.form.get("trim", 0))    # da -30 a +30
        speed = int(request.form.get("speed", 60))  # da 20 a 100

        # Applica velocità base e correzione trim ai motori
        left_speed  = max(0, min(100, speed - trim))
        right_speed = max(0, min(100, speed + trim))
        Ab.setSpeed(left_speed, right_speed)

        if movimentoRicevuto == "av":
            Ab.forward()
        elif movimentoRicevuto == "in":
            Ab.backward()
        elif movimentoRicevuto == "si":
            Ab.left()
        elif movimentoRicevuto == "de":
            Ab.right()
        elif movimentoRicevuto == "avsx":
            Ab.forward_left()
        elif movimentoRicevuto == "avdx":
            Ab.forward_right()
        elif movimentoRicevuto == "insx":
            Ab.backward_left()
        elif movimentoRicevuto == "indx":
            Ab.backward_right()
        elif movimentoRicevuto == "s":
            Ab.stop()
        elif movimentoRicevuto == "90r":
            Ab.r90()
        elif movimentoRicevuto == "90l":
            Ab.l90()
        else:
            return jsonify({"status": "error", "msg": "Comando non riconosciuto"}), 400

        return jsonify({"status": "ok", "comando": movimentoRicevuto})
    else:
        return render_template("index.html")

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5550, debug=False, use_reloader=False)